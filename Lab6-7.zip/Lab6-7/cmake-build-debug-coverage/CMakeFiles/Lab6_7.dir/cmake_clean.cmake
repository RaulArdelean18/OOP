file(REMOVE_RECURSE
  "CMakeFiles/Lab6_7.dir/Domain/domain.cpp.o"
  "CMakeFiles/Lab6_7.dir/Domain/domain.cpp.o.d"
  "CMakeFiles/Lab6_7.dir/main.cpp.o"
  "CMakeFiles/Lab6_7.dir/main.cpp.o.d"
  "CMakeFiles/Lab6_7.dir/repo/repo.cpp.o"
  "CMakeFiles/Lab6_7.dir/repo/repo.cpp.o.d"
  "CMakeFiles/Lab6_7.dir/serv/service.cpp.o"
  "CMakeFiles/Lab6_7.dir/serv/service.cpp.o.d"
  "CMakeFiles/Lab6_7.dir/ui/ui.cpp.o"
  "CMakeFiles/Lab6_7.dir/ui/ui.cpp.o.d"
  "CMakeFiles/Lab6_7.dir/validator/validator.cpp.o"
  "CMakeFiles/Lab6_7.dir/validator/validator.cpp.o.d"
  "Lab6_7"
  "Lab6_7.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Lab6_7.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
