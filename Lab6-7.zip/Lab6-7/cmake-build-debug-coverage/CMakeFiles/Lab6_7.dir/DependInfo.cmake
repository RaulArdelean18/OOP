
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab6-7/Domain/domain.cpp" "CMakeFiles/Lab6_7.dir/Domain/domain.cpp.o" "gcc" "CMakeFiles/Lab6_7.dir/Domain/domain.cpp.o.d"
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab6-7/main.cpp" "CMakeFiles/Lab6_7.dir/main.cpp.o" "gcc" "CMakeFiles/Lab6_7.dir/main.cpp.o.d"
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab6-7/repo/repo.cpp" "CMakeFiles/Lab6_7.dir/repo/repo.cpp.o" "gcc" "CMakeFiles/Lab6_7.dir/repo/repo.cpp.o.d"
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab6-7/serv/service.cpp" "CMakeFiles/Lab6_7.dir/serv/service.cpp.o" "gcc" "CMakeFiles/Lab6_7.dir/serv/service.cpp.o.d"
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab6-7/ui/ui.cpp" "CMakeFiles/Lab6_7.dir/ui/ui.cpp.o" "gcc" "CMakeFiles/Lab6_7.dir/ui/ui.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
