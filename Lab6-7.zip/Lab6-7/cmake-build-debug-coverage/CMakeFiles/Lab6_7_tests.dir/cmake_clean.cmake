file(REMOVE_RECURSE
  "CMakeFiles/Lab6_7_tests.dir/Domain/domain.cpp.o"
  "CMakeFiles/Lab6_7_tests.dir/Domain/domain.cpp.o.d"
  "CMakeFiles/Lab6_7_tests.dir/repo/repo.cpp.o"
  "CMakeFiles/Lab6_7_tests.dir/repo/repo.cpp.o.d"
  "CMakeFiles/Lab6_7_tests.dir/serv/service.cpp.o"
  "CMakeFiles/Lab6_7_tests.dir/serv/service.cpp.o.d"
  "CMakeFiles/Lab6_7_tests.dir/tests/tests.cpp.o"
  "CMakeFiles/Lab6_7_tests.dir/tests/tests.cpp.o.d"
  "CMakeFiles/Lab6_7_tests.dir/validator/validator.cpp.o"
  "CMakeFiles/Lab6_7_tests.dir/validator/validator.cpp.o.d"
  "Lab6_7_tests"
  "Lab6_7_tests.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Lab6_7_tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
