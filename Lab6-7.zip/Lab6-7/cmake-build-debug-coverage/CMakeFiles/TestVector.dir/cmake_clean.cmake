file(REMOVE_RECURSE
  "CMakeFiles/TestVector.dir/VectorDinamicCPP/VectorDinamicCPP/main.cpp.o"
  "CMakeFiles/TestVector.dir/VectorDinamicCPP/VectorDinamicCPP/main.cpp.o.d"
  "TestVector"
  "TestVector.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/TestVector.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
