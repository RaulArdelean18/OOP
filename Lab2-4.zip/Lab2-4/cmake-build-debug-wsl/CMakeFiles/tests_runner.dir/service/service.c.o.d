CMakeFiles/tests_runner.dir/service/service.c.o: \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/service/service.c \
 /usr/include/stdc-predef.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/service/service.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/service/../repo/repo.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/service/../repo/../utils/vector.h \
 /usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/service/../repo/../domain/car.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/service/../validator/validator.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/service/../validator/../domain/car.h \
 /usr/include/string.h \
 /usr/include/x86_64-linux-gnu/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/x86_64-linux-gnu/bits/wordsize.h \
 /usr/include/x86_64-linux-gnu/bits/timesize.h \
 /usr/include/x86_64-linux-gnu/sys/cdefs.h \
 /usr/include/x86_64-linux-gnu/bits/long-double.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs.h \
 /usr/include/x86_64-linux-gnu/gnu/stubs-64.h \
 /usr/include/x86_64-linux-gnu/bits/types/locale_t.h \
 /usr/include/x86_64-linux-gnu/bits/types/__locale_t.h \
 /usr/include/strings.h
