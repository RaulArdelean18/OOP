CMakeFiles/tests_runner.dir/test_main.c.o: \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/test_main.c \
 /usr/include/stdc-predef.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/tests/test.h
