CMakeFiles/OOP.dir/main.c.o: \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/main.c \
 /usr/include/stdc-predef.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/repo/repo.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/repo/../utils/vector.h \
 /usr/lib/gcc/x86_64-linux-gnu/13/include/stddef.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/repo/../domain/car.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/service/service.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/service/../repo/repo.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/ui/console.h \
 /mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/ui/../service/service.h
