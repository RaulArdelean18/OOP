
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/domain/car.c" "CMakeFiles/tests_runner.dir/domain/car.c.o" "gcc" "CMakeFiles/tests_runner.dir/domain/car.c.o.d"
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/repo/repo.c" "CMakeFiles/tests_runner.dir/repo/repo.c.o" "gcc" "CMakeFiles/tests_runner.dir/repo/repo.c.o.d"
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/service/service.c" "CMakeFiles/tests_runner.dir/service/service.c.o" "gcc" "CMakeFiles/tests_runner.dir/service/service.c.o.d"
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/test_main.c" "CMakeFiles/tests_runner.dir/test_main.c.o" "gcc" "CMakeFiles/tests_runner.dir/test_main.c.o.d"
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/tests/test.c" "CMakeFiles/tests_runner.dir/tests/test.c.o" "gcc" "CMakeFiles/tests_runner.dir/tests/test.c.o.d"
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/utils/vector.c" "CMakeFiles/tests_runner.dir/utils/vector.c.o" "gcc" "CMakeFiles/tests_runner.dir/utils/vector.c.o.d"
  "/mnt/c/Users/Raul_A/Documents/GitHub/OOP/Lab2-4/validator/validator.c" "CMakeFiles/tests_runner.dir/validator/validator.c.o" "gcc" "CMakeFiles/tests_runner.dir/validator/validator.c.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
