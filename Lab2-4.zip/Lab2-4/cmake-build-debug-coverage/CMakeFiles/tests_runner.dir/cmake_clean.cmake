file(REMOVE_RECURSE
  "CMakeFiles/tests_runner.dir/domain/car.c.o"
  "CMakeFiles/tests_runner.dir/domain/car.c.o.d"
  "CMakeFiles/tests_runner.dir/repo/repo.c.o"
  "CMakeFiles/tests_runner.dir/repo/repo.c.o.d"
  "CMakeFiles/tests_runner.dir/service/service.c.o"
  "CMakeFiles/tests_runner.dir/service/service.c.o.d"
  "CMakeFiles/tests_runner.dir/test_main.c.o"
  "CMakeFiles/tests_runner.dir/test_main.c.o.d"
  "CMakeFiles/tests_runner.dir/tests/test.c.o"
  "CMakeFiles/tests_runner.dir/tests/test.c.o.d"
  "CMakeFiles/tests_runner.dir/utils/vector.c.o"
  "CMakeFiles/tests_runner.dir/utils/vector.c.o.d"
  "CMakeFiles/tests_runner.dir/validator/validator.c.o"
  "CMakeFiles/tests_runner.dir/validator/validator.c.o.d"
  "tests_runner"
  "tests_runner.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/tests_runner.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
