file(REMOVE_RECURSE
  "CMakeFiles/OOP.dir/domain/car.c.o"
  "CMakeFiles/OOP.dir/domain/car.c.o.d"
  "CMakeFiles/OOP.dir/main.c.o"
  "CMakeFiles/OOP.dir/main.c.o.d"
  "CMakeFiles/OOP.dir/repo/repo.c.o"
  "CMakeFiles/OOP.dir/repo/repo.c.o.d"
  "CMakeFiles/OOP.dir/service/service.c.o"
  "CMakeFiles/OOP.dir/service/service.c.o.d"
  "CMakeFiles/OOP.dir/ui/console.c.o"
  "CMakeFiles/OOP.dir/ui/console.c.o.d"
  "CMakeFiles/OOP.dir/utils/vector.c.o"
  "CMakeFiles/OOP.dir/utils/vector.c.o.d"
  "CMakeFiles/OOP.dir/validator/validator.c.o"
  "CMakeFiles/OOP.dir/validator/validator.c.o.d"
  "OOP"
  "OOP.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/OOP.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
